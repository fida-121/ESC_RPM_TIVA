/***************************************************************
 * File        : pwm_timer.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Generates 50Hz PWM signals using Timer0A and 
 *               Timer1A (one-shot mode) for ESC control. 
 *               Provides function to set PWM pulse width.
 ***************************************************************/

#include "TM4C123.h"
#include "gpio.h"
#include "pwm_timer.h"

volatile unsigned long pulse_us = 1200;

void Timer0A_50Hz_Init(void){
    SYSCTL->RCGCTIMER |= (1U << 0);
    for (volatile int i=0; i<3; i++);
    TIMER0->CTL = 0;
    TIMER0->CFG = 0;
    TIMER0->TAMR = 0x02;
    TIMER0->TAILR = 16000000/50 - 1;
    TIMER0->ICR = 0x1;
    TIMER0->IMR = 0x1;
    NVIC->ISER[0] |= (1U << 19);
    TIMER0->CTL |= 0x1;
}

void Timer1A_OneShot_Init(void){
    SYSCTL->RCGCTIMER |= (1U << 1);
    for (volatile int i=0; i<3; i++);
    TIMER1->CTL &= ~0x1;
    TIMER1->CFG = 0x04;
    TIMER1->TAMR = 0x01;
    TIMER1->ICR = 0x1;
    TIMER1->IMR = 0x1;
    NVIC->ISER[0] |= (1U << 21);
}

void set_pulse_width_us(unsigned long us){
    if (us < 1000) us = 1000;
    if (us > 2000) us = 2000;
    pulse_us = us;
}

void TIMER0A_Handler(void){
    TIMER0->ICR = 0x1;
    GPIOB->DATA |= (1U << 6);
    TIMER1->TAILR = (16000000/1000000)*pulse_us - 1;
    TIMER1->CTL |= 0x1;
}

void TIMER1A_Handler(void){
    TIMER1->ICR = 0x1;
    GPIOB->DATA &= ~(1U << 6);
}
