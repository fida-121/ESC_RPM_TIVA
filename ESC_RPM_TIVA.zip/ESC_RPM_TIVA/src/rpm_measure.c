/***************************************************************
 * File        : rpm_measure.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Uses Timer2A to measure RPM from optocoupler 
 *               pulse count and compute revolutions per minute.
 ***************************************************************/

#include "TM4C123.h"
#include "gpio.h"
#include "rpm_measure.h"

volatile uint32_t rpm = 0;

void Timer2A_RPM_Measure_Init(void){
    SYSCTL->RCGCTIMER |= (1U << 2);
    for (volatile int i=0; i<3; i++);
    TIMER2->CTL = 0;
    TIMER2->CFG = 0;
    TIMER2->TAMR = 0x02;
    TIMER2->TAILR = 16000000 - 1;
    TIMER2->ICR = 0x1;
    TIMER2->IMR = 0x1;
    NVIC->ISER[0] |= (1U << 23);
    TIMER2->CTL |= 0x1;
}

void TIMER2A_Handler(void){
    TIMER2->ICR = 0x1;
    rpm = (pulse_count * 60) / 2;
    pulse_count = 0;
}
