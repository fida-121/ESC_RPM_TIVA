/***************************************************************
 * File        : pll.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Configures the Phase-Locked Loop (PLL) to 
 *               stabilize and set the system clock frequency.
 ***************************************************************/

#include "TM4C123.h"
#include "pll.h"

void PLL_Init(void){
    SYSCTL->RCC2 |= 0x80000000;
    SYSCTL->RCC2 |= 0x00000800;
    SYSCTL->RCC = (SYSCTL->RCC &~ 0x000007C0) + 0x00000540;
    SYSCTL->RCC2 &= ~0x00000070;
    SYSCTL->RCC2 &= ~0x00002000;
    SYSCTL->RCC2 |= 0x40000000;
    SYSCTL->RCC2 = (SYSCTL->RCC2 &~ 0x1FC00000) + (24<<22);
    while((SYSCTL->RIS & 0x00000040)==0){}
    SYSCTL->RCC2 &= ~0x00000800;
}
