/***************************************************************
 * Project Title : ESC Control and RPM Measurement using TM4C123
 * Author        : Fida Hussain
 * Institution   : University of Engineering and Technology (UET), Lahore
 * Semester      : 5th Semester (Mechatronics Engineering)
 * 
 * Description:
 * This embedded C program is designed to control a BLDC motor 
 * via an Electronic Speed Controller (ESC) using PWM signals 
 * generated from the TM4C123 microcontroller. The program 
 * performs the following functions:
 * 
 * 1. Generates a 50Hz PWM signal (1�2 ms pulse width) on PB6 
 *    to control motor throttle.
 * 2. Reads analog input from a potentiometer on PE3 (ADC0) 
 *    to adjust the ESC pulse width.
 * 3. Measures motor RPM using an optocoupler connected to PB2.
 * 4. Calculates and displays live RPM and PWM pulse width 
 *    via UART0 at 9600 baud.
 * 5. Uses PLL for stable system clock and Timer modules for 
 *    PWM, RPM timing, and periodic interrupts.
 * 
 * File Organization:
 * - main.c           : Main program logic
 * - pll.c/.h         : Clock configuration
 * - gpio.c/.h        : GPIO and interrupt setup
 * - pwm_timer.c/.h   : PWM generation (Timer0A, Timer1A)
 * - rpm_measure.c/.h : RPM counting (Timer2A)
 * - uart.c/.h        : Serial communication
 * - adc.c/.h         : Analog-to-digital conversion
 * 
 * Date Created  : October 2025
 ***************************************************************/

#include "TM4C123.h"
#include "pll.h"
#include "gpio.h"
#include "pwm_timer.h"
#include "rpm_measure.h"
#include "uart.h"
#include "adc.h"
#include <stdio.h>

volatile unsigned long manual_pulse = 1215;
extern volatile uint32_t rpm;  // from rpm_measure.c

int main(void){
    PLL_Init();
    GPIOB_Init();
    UART0_Init();
    ADC0_Init();
    Timer1A_OneShot_Init();
    Timer0A_50Hz_Init();
    Timer2A_RPM_Measure_Init();
    __enable_irq();

    set_pulse_width_us(1000);
    for (volatile int i=0; i<12000000; i++); // 3s delay
    set_pulse_width_us(1200);

    char msg[40];
    while(1){
        uint16_t adc_val = ADC0_Read();
        manual_pulse = 1000 + ((adc_val * 500) / 4095);
        set_pulse_width_us(manual_pulse);
        sprintf(msg, "RPM: %lu   Pulse: %lu us\r\n", rpm, manual_pulse);
        UART0_SendString(msg);
        for (volatile int d=0; d<1600000; d++); // 0.1s delay
    }
}
