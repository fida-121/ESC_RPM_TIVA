/***************************************************************
 * File        : uart.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Initializes UART0 for serial communication at 
 *               9600 baud and provides a string transmit function.
 ***************************************************************/

#include "TM4C123.h"
#include "uart.h"

void UART0_Init(void){
    SYSCTL->RCGCUART |= 1;
    SYSCTL->RCGCGPIO |= 1;
    for (volatile int i=0; i<3; i++);

    GPIOA->AFSEL |= 0x03;
    GPIOA->PCTL = (GPIOA->PCTL & 0xFFFFFF00) | 0x00000011;
    GPIOA->DEN |= 0x03;

    UART0->CTL &= ~0x01;
    UART0->IBRD = 104;
    UART0->FBRD = 11;
    UART0->LCRH = 0x70;
    UART0->CC = 0x0;
    UART0->CTL |= 0x301;
}

void UART0_SendString(char *str){
    while(*str){
        while((UART0->FR & 0x20) != 0);
        UART0->DR = *str++;
    }
}
