/***************************************************************
 * File        : gpio.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Initializes GPIO Port B for ESC PWM output 
 *               (PB6) and optocoupler RPM input (PB2). 
 *               Handles pulse counting interrupt.
 ***************************************************************/

#include "TM4C123.h"
#include "gpio.h"

volatile uint32_t pulse_count = 0;

void GPIOB_Init(void){
    SYSCTL->RCGCGPIO |= (1U << 1);
    for (volatile int i=0; i<3; i++);

    GPIOB->DIR |= (1U << 6);
    GPIOB->DEN |= (1U << 6) | (1U << 2);
    GPIOB->DATA &= ~(1U << 6);

    GPIOB->DIR &= ~(1U << 2);
    GPIOB->IS  &= ~(1U << 2);
    GPIOB->IBE &= ~(1U << 2);
    GPIOB->IEV &= ~(1U << 2);
    GPIOB->ICR |= (1U << 2);
    GPIOB->IM  |= (1U << 2);

    NVIC->ISER[0] |= (1U << 1);
}

void GPIOB_Handler(void){
    if(GPIOB->MIS & (1U << 2)){
        pulse_count++;
        GPIOB->ICR |= (1U << 2);
    }
}
