/***************************************************************
 * File        : adc.c
 * Author      : Fida Hussain (UET Lahore, 5th Semester)
 * Description : Configures ADC0 to read analog input from PE3 
 *               (AIN0) to control PWM pulse width via a 
 *               potentiometer.
 ***************************************************************/

#include "TM4C123.h"
#include "adc.h"

void ADC0_Init(void){
    SYSCTL->RCGCADC |= 1;
    SYSCTL->RCGCGPIO |= (1U << 4);
    for (volatile int i=0; i<3; i++);

    GPIOE->AFSEL |= (1U << 3);
    GPIOE->DEN &= ~(1U << 3);
    GPIOE->AMSEL |= (1U << 3);

    ADC0->ACTSS &= ~(1U << 3);
    ADC0->EMUX &= ~0xF000;
    ADC0->SSMUX3 = 0;
    ADC0->SSCTL3 = 0x06;
    ADC0->ACTSS |= (1U << 3);
}

uint16_t ADC0_Read(void){
    ADC0->PSSI |= (1U << 3);
    while((ADC0->RIS & (1U << 3)) == 0);
    uint16_t result = ADC0->SSFIFO3 & 0xFFF;
    ADC0->ISC = (1U << 3);
    return result;
}
