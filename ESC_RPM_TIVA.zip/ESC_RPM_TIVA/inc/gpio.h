#ifndef GPIO_H
#define GPIO_H

#include <stdint.h>

extern volatile uint32_t pulse_count;

void GPIOB_Init(void);

#endif
