#ifndef UART_H
#define UART_H

void UART0_Init(void);
void UART0_SendString(char *str);

#endif
