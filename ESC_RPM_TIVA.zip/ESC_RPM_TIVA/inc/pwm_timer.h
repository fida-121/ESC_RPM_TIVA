#ifndef PWM_TIMER_H
#define PWM_TIMER_H

#include <stdint.h>

void Timer0A_50Hz_Init(void);
void Timer1A_OneShot_Init(void);
void set_pulse_width_us(unsigned long us);

#endif
