#ifndef PLL_H
#define PLL_H

void PLL_Init(void);

#endif
